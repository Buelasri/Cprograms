#include<stdio.h>
int main(){
    int a=10;
    int b=20;
printf("sum of two numbers %d\n",a+b);
return 0;
}