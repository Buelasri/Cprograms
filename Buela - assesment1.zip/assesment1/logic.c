#include<stdio.h>
int main(){
    int a=5;
    int b=8;
    printf("logical AND:a=%d\n",(a<8&&b>5));
    printf("logical OR:b=%d\n",(a<6||b>5));
    return 0;
}