#include<stdio.h>
int main(){
    int a=45;
    int b=45;
   printf("equal:%d\n",a==b);
   printf("greater:%d\n",a>b);
   printf("less:%d\n",a<b);
   printf("greater or equal:%d\n",a>=b);
   printf("less or equal:%d\n",a<=b);
   printf("not equal:%d\n",b!=a);
   return 0;
}