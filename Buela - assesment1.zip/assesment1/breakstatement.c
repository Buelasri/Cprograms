#include<stdio.h>
int main(){
    int n;
    printf("enter your choice");
    scanf("%d",&n);
    if(n<0){
        printf("negative number\n");
    }else{
        printf("positive number\n");
    }
    
        return 0;
    }