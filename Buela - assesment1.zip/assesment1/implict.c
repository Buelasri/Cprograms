#include<stdio.h>
int main(){
    int a=10;
    float b=a;
    printf("valuue of b:%f",b);
    return 0;
}