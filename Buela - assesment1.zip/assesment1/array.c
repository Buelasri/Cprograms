#include<stdio.h>
int main(){
    int numbers[7]={6,9,18,31,23,25,8};
    for(int i=0;i<7;i++){
        printf("element%d:%d\n",i,numbers[i]);
    }
    return 0;
}


    
