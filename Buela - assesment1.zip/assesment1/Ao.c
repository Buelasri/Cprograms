#include<stdio.h>
int main(){
    int a=5;
    int b=6;
    printf("printing a&b values a=%d,b=%d\n",a,b);
    printf("addition of a&b are\n");
    printf("addition of a=%d,b=%d\n",a+b);
    printf("subtraction of a&b are\n");
    printf("subtraction of a=%d,b=%d\n",a-b);
    printf("multiplication of a&b are\n");
    printf("multiplicaton of a=%d,b=%d\n",a*b);
    printf("division of a&b are\n");
    printf("division of a=%d,b=%d\n",a%b);
    return 0;
}