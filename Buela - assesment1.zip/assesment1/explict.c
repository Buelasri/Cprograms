#include<stdio.h>
int main(){
    float a=10;
    int b=(int)a;
    printf("valuue of b:%d",b);
    return 0;
}