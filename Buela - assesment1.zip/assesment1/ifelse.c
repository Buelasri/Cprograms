#include<stdio.h>
int main(){
    int a=34;
    int b=23;
    
    if (a>b)
    {
       printf("is max")
    }
    else{
        printf("is not max");
    }
    return 0;
}